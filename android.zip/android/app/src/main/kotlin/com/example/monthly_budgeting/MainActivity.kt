package com.example.monthly_budgeting

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
