import sys
from pathlib import Path
p = Path(r'c:\flutter_dev\Budgeting_project\monthly_budgeting\lib\dashboard_screen.dart')
s = p.read_text(encoding='utf-8')
stack = []
pairs = {'(':')','{':'}','[':']'}
openers = set(pairs.keys())
closers = {v:k for k,v in pairs.items()}
for i,ch in enumerate(s, start=1):
    if ch in openers:
        stack.append((ch,i))
    elif ch in closers:
        if not stack:
            print(f'Unmatched closer {ch} at index {i}')
            sys.exit(0)
        last, pos = stack.pop()
        if pairs[last] != ch:
            print(f'Mismatched {last} at {pos} with {ch} at {i}')
            sys.exit(0)
if stack:
    last, pos = stack[-1]
    print(f'Unclosed opener {last} at index {pos}')
else:
    print('All balanced')
