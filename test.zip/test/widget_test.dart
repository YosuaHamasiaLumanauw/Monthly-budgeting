import 'package:flutter_test/flutter_test.dart';
import 'package:monthly_budgeting/main.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp(isLoggedIn: false));
    expect(find.text('Monthly Budgeting'), findsOneWidget);
  });
}
