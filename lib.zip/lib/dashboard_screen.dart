import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'transaction_model.dart';
import 'transaction_dialog.dart';
import 'login_screen.dart';



class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<TransactionModel> _allTransactions = [];
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month);
  String _userName = 'User';

  // Date boundaries
  final DateTime _minMonth = DateTime(2026, 1);
  final DateTime _maxMonth = DateTime(2030, 12);

  @override
  void initState() {
    super.initState();
    _loadData();
  }

    Future<void> _loadData() async {
  final user = _auth.currentUser;

  if (user != null) {
    final doc = await _firestore
        .collection('users')
        .doc(user.uid)
        .get();

    setState(() {
      _userName = doc.data()?['name'] ?? 'User';
    });
  }

  await _loadTransactionsFromFirestore();
}

  Future<void> _saveTransactions() async {
    final prefs = await SharedPreferences.getInstance();
    final transactionsJson =
        _allTransactions.map((t) => jsonEncode(t.toJson())).toList();
    await prefs.setStringList('transactions', transactionsJson);
  }
  Future<void> _loadTransactionsFromFirestore() async {
  final user = _auth.currentUser;

  if (user == null) return;

  final snapshot = await _firestore
      .collection('users')
      .doc(user.uid)
      .collection('transactions')
      .get();

  final transactions = snapshot.docs.map((doc) {
    return TransactionModel.fromJson(doc.data());
  }).toList();

  setState(() {
    _allTransactions = transactions;
  });
}

Future<void> _saveTransactionToFirestore(
  TransactionModel transaction,
) async {
  final user = _auth.currentUser;

  if (user == null) return;

  await _firestore
      .collection('users')
      .doc(user.uid)
      .collection('transactions')
      .doc(transaction.id)
      .set(transaction.toJson());
}

  List<TransactionModel> get _filteredTransactions {
    return _allTransactions.where((t) {
      return t.date.year == _selectedMonth.year &&
          t.date.month == _selectedMonth.month;
    }).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
  }

  double get _totalIncome {
    return _filteredTransactions
        .where((t) => t.isIncome)
        .fold(0.0, (sum, t) => sum + t.amount);
  }

  double get _totalExpenses {
    return _filteredTransactions
        .where((t) => !t.isIncome)
        .fold(0.0, (sum, t) => sum + t.amount);
  }

  double get _totalBalance => _totalIncome - _totalExpenses;

  Future<void> _addTransaction(TransactionModel transaction) async {
    // Gunakan bulan yang sedang dipilih, bukan bulan sekarang
    final correctedDate = DateTime(
      _selectedMonth.year,
      _selectedMonth.month,
      transaction.date.day,
      transaction.date.hour,
      transaction.date.minute,
      transaction.date.second,
    );
    final corrected = TransactionModel(
      id: transaction.id,
      title: transaction.title,
      amount: transaction.amount,
      category: transaction.category,
      isIncome: transaction.isIncome,
      date: correctedDate,
    );
    setState(() {
      _allTransactions.add(corrected);
    });
   await _saveTransactionToFirestore(corrected);
  }

  void _previousMonth() {
    final prev = DateTime(_selectedMonth.year, _selectedMonth.month - 1);
    if (!prev.isBefore(_minMonth)) {
      setState(() => _selectedMonth = prev);
    }
  }

  void _nextMonth() {
    final next = DateTime(_selectedMonth.year, _selectedMonth.month + 1);
    if (!next.isAfter(_maxMonth)) {
      setState(() => _selectedMonth = next);
    }
  }

  String _formatCurrency(double amount) {
    final formatter = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    );
    return formatter.format(amount);
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', false);
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  void _showProfileMenu(BuildContext context) {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final offset = renderBox.localToGlobal(Offset.zero);

    showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(
        offset.dx,
        offset.dy + renderBox.size.height,
        offset.dx + renderBox.size.width,
        0,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      items: <PopupMenuEntry<String>>[
        PopupMenuItem<String>(
          enabled: false,
          value: 'profile',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _userName,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A1A1A),
                ),
              ),
              const SizedBox(height: 2),
              const Text(
                'User Profile',
                style: TextStyle(fontSize: 12, color: Color(0xFF757575)),
              ),
            ],
          ),
        ),
        const PopupMenuDivider(),
        PopupMenuItem<String>(
          value: 'logout',
          child: Row(
            children: const [
              Icon(Icons.logout_rounded, size: 18, color: Colors.redAccent),
              SizedBox(width: 8),
              Text(
                'Logout',
                style: TextStyle(color: Colors.redAccent),
              ),
            ],
          ),
        ),
      ],
    ).then((value) {
      if (value == 'logout') _logout();
    });
  }

  Color _getCategoryColor(String category) {
    const colors = {
      'Food': Color(0xFFFF7043),
      'Transport': Color(0xFF42A5F5),
      'Rent': Color(0xFFAB47BC),
      'Shopping': Color(0xFFEC407A),
      'Entertainment': Color(0xFFFFCA28),
      'Health': Color(0xFF26A69A),
      'Other': Color(0xFF78909C),
      'Salary': Color(0xFF66BB6A),
      'Freelance': Color(0xFF29B6F6),
      'Gift': Color(0xFFF06292),
    };
    return colors[category] ?? const Color(0xFF78909C);
  }

  IconData _getCategoryIcon(String category) {
    const icons = {
      'Food': Icons.restaurant_rounded,
      'Transport': Icons.directions_car_rounded,
      'Rent': Icons.home_rounded,
      'Shopping': Icons.shopping_bag_rounded,
      'Entertainment': Icons.movie_rounded,
      'Health': Icons.favorite_rounded,
      'Other': Icons.more_horiz_rounded,
      'Salary': Icons.work_rounded,
      'Freelance': Icons.laptop_rounded,
      'Gift': Icons.card_giftcard_rounded,
    };
    return icons[category] ?? Icons.attach_money_rounded;
  }

  void _showTransactionMenu(BuildContext context, TransactionModel t) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFE0E0E0),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 12),
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFE8F5E9),
                  child: Icon(Icons.edit_rounded, color: Color(0xFF2E7D32), size: 20),
                ),
                title: const Text('Edit Transaction', style: TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(t.title, style: const TextStyle(fontSize: 12, color: Color(0xFF9E9E9E))),
                onTap: () {
                  Navigator.pop(ctx);
                  _openEditDialog(t);
                },
              ),
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFFFEBEE),
                  child: Icon(Icons.delete_rounded, color: Colors.redAccent, size: 20),
                ),
                title: const Text('Delete Transaction', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.redAccent)),
                subtitle: Text(t.title, style: const TextStyle(fontSize: 12, color: Color(0xFF9E9E9E))),
                onTap: () {
                  Navigator.pop(ctx);
                  _deleteTransaction(t.id);
                },
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  void _deleteTransaction(String id) {
    setState(() {
      _allTransactions.removeWhere((t) => t.id == id);
    });
    _saveTransactions();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Transaction deleted'),
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        action: SnackBarAction(
          label: 'Undo',
          textColor: Colors.white,
          onPressed: () {},
        ),
      ),
    );
  }

  void _openEditDialog(TransactionModel transaction) {
    showDialog(
      context: context,
      builder: (context) => TransactionDialog(
        onAdd: (updated) {
          // Pertahankan tanggal asli transaksi, jangan pakai DateTime.now()
          final corrected = TransactionModel(
            id: transaction.id,
            title: updated.title,
            amount: updated.amount,
            category: updated.category,
            isIncome: updated.isIncome,
            date: transaction.date, // ← pakai tanggal asli
          );
          setState(() {
            final index = _allTransactions.indexWhere((t) => t.id == transaction.id);
            if (index != -1) _allTransactions[index] = corrected;
          });
          _saveTransactions();
        },
        existingTransaction: transaction,
      ),
    );
  }

  void _openTransactionDialog() {
    showDialog(
      context: context,
      builder: (context) => TransactionDialog(onAdd: _addTransaction),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width > 600;
    final filtered = _filteredTransactions;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: ScrollConfiguration(
        behavior: ScrollConfiguration.of(context).copyWith(overscroll: false),
        child: SafeArea(
          child: Column(
            children: [
            // ── HEADER TETAP DIAM ──
            Container(
              color: Colors.white,
              child: Column(
                children: [
                  // App Bar
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: isTablet ? 32 : 16,
                      vertical: 12,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: const Color(0xFF2E7D32),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.account_balance_wallet_rounded,
                            color: Colors.white,
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 10),
                        const Expanded(
                          child: Text(
                            'Monthly Budgeting',
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF1A1A1A),
                            ),
                          ),
                        ),
                        Builder(
                          builder: (ctx) => GestureDetector(
                            onTap: () => _showProfileMenu(ctx),
                            child: Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: const Color(0xFF2E7D32).withOpacity(0.1),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.person_rounded,
                                color: Color(0xFF2E7D32),
                                size: 22,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Month Selector
                  Padding(
                    padding: EdgeInsets.only(
                      left: isTablet ? 32 : 16,
                      right: isTablet ? 32 : 16,
                      bottom: 12,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          onPressed: _previousMonth,
                          icon: const Icon(Icons.chevron_left_rounded),
                          style: IconButton.styleFrom(
                            foregroundColor: _selectedMonth.isAtSameMomentAs(_minMonth)
                                ? const Color(0xFFBDBDBD)
                                : const Color(0xFF2E7D32),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            DateFormat('MMMM yyyy').format(_selectedMonth),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF1A1A1A),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: _nextMonth,
                          icon: const Icon(Icons.chevron_right_rounded),
                          style: IconButton.styleFrom(
                            foregroundColor: _selectedMonth.isAtSameMomentAs(_maxMonth)
                                ? const Color(0xFFBDBDBD)
                                : const Color(0xFF2E7D32),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(height: 1, color: Color(0xFFEEEEEE)),
                ],
              ),
            ),

            // ── SUMMARY CARDS DIAM ──
            Padding(
              padding: EdgeInsets.fromLTRB(
                isTablet ? 32 : 16,
                12,
                isTablet ? 32 : 16,
                0,
              ),
              child: isTablet
                  ? Row(
                      children: [
                        Expanded(child: _buildSummaryCard('TOTAL BALANCE', _totalBalance, null)),
                        const SizedBox(width: 12),
                        Expanded(child: _buildSummaryCard('INCOME', _totalIncome, true)),
                        const SizedBox(width: 12),
                        Expanded(child: _buildSummaryCard('EXPENSES', _totalExpenses, false)),
                      ],
                    )
                  : Column(
                      children: [
                        _buildSummaryCard('TOTAL BALANCE', _totalBalance, null, fullWidth: true),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(child: _buildSummaryCard('INCOME', _totalIncome, true)),
                            const SizedBox(width: 10),
                            Expanded(child: _buildSummaryCard('EXPENSES', _totalExpenses, false)),
                          ],
                        ),
                      ],
                    ),
            ),
            const SizedBox(height: 16),

            // ── JUDUL RECENT TRANSACTIONS DIAM ──
            Padding(
              padding: EdgeInsets.symmetric(
                horizontal: isTablet ? 32 : 16,
                vertical: 12,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Recent Transactions',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1A1A1A),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF2E7D32).withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      '${filtered.length} items',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF2E7D32),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── HANYA ITEM TRANSAKSI YANG SCROLL ──
            Expanded(
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(
                  parent: ClampingScrollPhysics(),
                ),
                padding: const EdgeInsets.only(bottom: 80),
                children: [

                  // Transaction List or Empty State
                  if (filtered.isEmpty)
                    Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: isTablet ? 32 : 16,
                        vertical: 32,
                      ),
                      child: Column(
                        children: [
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: const Color(0xFF2E7D32).withOpacity(0.08),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.calendar_month_rounded,
                              size: 40,
                              color: Color(0xFF2E7D32),
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'No transactions this month',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Color(0xFF424242)),
                          ),
                          const SizedBox(height: 6),
                          const Text(
                            'Add your first one',
                            style: TextStyle(fontSize: 14, color: Color(0xFF9E9E9E)),
                          ),
                        ],
                      ),
                    )
                  else
                    ...filtered.map((t) => Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: isTablet ? 32 : 16,
                        vertical: 4,
                      ),
                      child: Dismissible(
                        key: Key(t.id),
                        direction: DismissDirection.endToStart,
                        dismissThresholds: const {DismissDirection.endToStart: 0.3},
                        movementDuration: const Duration(milliseconds: 200),
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          decoration: BoxDecoration(
                            color: Colors.redAccent,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.delete_rounded, color: Colors.white, size: 24),
                              SizedBox(height: 4),
                              Text('Delete', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        confirmDismiss: (direction) async {
                          return await showDialog<bool>(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                              title: const Text('Delete Transaction', style: TextStyle(fontWeight: FontWeight.bold)),
                              content: Text('Delete "${t.title}"?'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(ctx, false),
                                  child: const Text('Cancel', style: TextStyle(color: Color(0xFF757575))),
                                ),
                                ElevatedButton(
                                  onPressed: () => Navigator.pop(ctx, true),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.redAccent,
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                  ),
                                  child: const Text('Delete'),
                                ),
                              ],
                            ),
                          ) ?? false;
                        },
                        onDismissed: (_) => _deleteTransaction(t.id),
                        child: GestureDetector(
                          onTap: () => _openEditDialog(t),
                          onLongPress: () => _showTransactionMenu(context, t),
                          child: _buildTransactionCard(t),
                        ),
                      ),
                    )),
                ],
              ),
            ),
          ],
        ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _openTransactionDialog,
        backgroundColor: const Color(0xFF1A1A1A),
        foregroundColor: Colors.white,
        shape: const CircleBorder(),
        elevation: 4,
        child: const Icon(Icons.add_rounded, size: 28),
      ),
    );
  }

  Widget _buildSummaryCard(String title, double amount, bool? isPositiveColor,
      {bool fullWidth = false}) {
    // null = auto (hijau jika >= 0, merah jika < 0)
    final color = isPositiveColor == null
        ? (amount >= 0 ? const Color(0xFF2E7D32) : Colors.redAccent)
        : (isPositiveColor ? const Color(0xFF2E7D32) : Colors.redAccent);

    return Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Color(0xFF9E9E9E),
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 8),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              _formatCurrency(amount.abs()),
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionCard(TransactionModel transaction) {
    final categoryColor = _getCategoryColor(transaction.category);
    final categoryIcon = _getCategoryIcon(transaction.category);
    final isIncome = transaction.isIncome;
    final amountColor = isIncome ? const Color(0xFF2E7D32) : Colors.redAccent;
    final amountPrefix = isIncome ? '+' : '-';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Icon
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: categoryColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(categoryIcon, color: categoryColor, size: 22),
          ),
          const SizedBox(width: 12),

          // Title & Category
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  transaction.title,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF1A1A1A),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    // Category Badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: categoryColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        transaction.category.toUpperCase(),
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          color: categoryColor,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      DateFormat('MMM d, hh:mm a').format(transaction.date),
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF9E9E9E),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Amount
          Text(
            '$amountPrefix${_formatCurrency(transaction.amount)}',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: amountColor,
            ),
          ),
        ],
      ),
    );
  }
}